x<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<body>
  
  <audio id="pop">
    <source src="son/sound-led.mp3" type="audio/mpeg">
  </audio>
    <div class="full">
        <img id="logo" class="logo" src="img/icon-site.png">
        <img id="lightopen" src="img/open-light.png">
        <h1 class="text-flicker-in-glow">Producti<span class="boldavant">on</span>s<br>d’avant-garde</h1>
    </div>
    
</body>

<script>
 
  $("#logo").click(function(){
  $("h1").addClass("show");
  $("#lightopen").addClass("show");
  $("#logo").addClass("none");
  $('audio#pop')[0].play()
  $('audio#pop')[0].currentTime = 1
  
});

</script>

<script type="text/javascript"> 

var obj = 'window.location.replace("http://127.0.0.1:8000/accueil");'; 
setTimeout(obj,7300); 
</script>

</html>