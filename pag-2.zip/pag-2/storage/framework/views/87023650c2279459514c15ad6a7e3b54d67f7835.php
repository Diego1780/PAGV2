<?php $__env->startSection('content'); ?>

    <center>
        <img src="/img/coming.jpg" alt="">    
    </center>

<?php $__env->stopSection(); ?>

</section>    


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yanis/pag/site-web/pag-2/resources/views/page.blade.php ENDPATH**/ ?>