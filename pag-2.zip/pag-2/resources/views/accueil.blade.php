@extends('layout')


@section('content')
    <section id="banner">
        <div style="background-color: #ffcc01;height: 86VH;">
            <h2 id="heading-banner" style="color: #000;">bienvenue</h2>
            <div id='scroll_down' >
                 <a href="#" style="color: rgb(0,0,0);"><i class="icon-arrow-down"></i></a>
            </div>
        </div>
    </section>
    <section class="text-left d-flex justify-content-around" id="work-one">
        <div id="work-left">
            <a href="{{ url('/coming') }}">
            <div class="card-work">
                <div style="height: 500px;width: 600px;background-color: #ffcc01;margin-top: 35px;"></div>
                <h1 style="font-size: 20px;color:black;">Heading</h1>
            </div>
            </a>
        </div>
        <div id="work-right">
        <a href="{{ url('/coming') }}">
            <div class="card-work">
                <div style="height: 200px;width: 315px;background-color: #ffcc01;margin-top: 35px;"></div>
                <h1 style="font-size: 20px;color:black;">Heading</h1>
            </div>
        </a>
        <a href="{{ url('/coming') }}">
            <div class="card-work">
                <div style="height: 200px;width: 315px;background-color: #ffcc01;margin-top: 35px;"></div>
                <h1 style="font-size: 20px;color:black;">Heading</h1>
            </div>
            </a>
            <a href="{{ url('/coming') }}">
            <div class="card-work">
                <div style="height: 200px;width: 315px;background-color: #ffcc01;margin-top: 35px;"></div>
                <h1 style="font-size: 20px;color:black;">Heading</h1>
            </div>
            </a>
            <a href="{{ url('/coming') }}">
            <div class="card-work">
                <div style="height: 200px;width: 315px;background-color: #ffcc01;margin-top: 35px;"></div>
                <h1 style="font-size: 20px;color:black;">Heading</h1>
            </div>
            </a>

            
                
        </div>
        </div>

       

    </section>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.2.1/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/@bootstrapstudio/bootstrap-better-nav/dist/bootstrap-better-nav.min.js"></script>

@endsection