<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Mail;
use App\Mail\ContactMail;

class ContactController extends Controller
{
    public function contact() 
    {
        return view('contact');
    } 

    public function sendEmail(Request $request) 
    {
        $details = 
        [
            'name' => $request->name,
            'surname' => $request->surname,
            'email' => $request->email,
            'phone' => $request->phone,
            'msg' => $request->msg,
        ];

        Mail::to('contact@ag-prod.com')->send(new ContactMail($details));
        return back()->with('message_sent','Votre message a bien été envoyé!');
    }
}

