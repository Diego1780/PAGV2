@extends('layout')


@section('content')

<section style="padding-top:100px;">

    <div class="container">
        <div class="row">
            <div class='col-md-6 offset-md-3' >
                <div class="card border-warning mb-3">
                    <div class="card-header border-warning mb-3">
                        Contactez-nous
                    </div>
                    <div class="card-body border-warning mb-3">
                    @if(Session::has('message_sent'))
                        <div class="alert alert-success" role="alert">
                            {{ Session::get('message_sent')}}
                        </div>
                    @endif
                        <form method="POST" action="{{route('contact.send') }}" enctype="multipart/form-data">
                        @csrf
                            <div class="form-group">
                                
                                <label for="name">Nom</label>
                                <input type="text" name="name" class="form-control">
                            </div>
                            
                            <div class="form-group">
                                
                                <label for="surname">Prénom</label>
                                <input type="text" name="surname" class="form-control">
                            </div>
                            
                            <div class="form-group">
                                
                                <label for="email">Email</label>
                                <input type="text" name="email" class="form-control">
                            </div>
                            <div class="form-group">
                                
                                <label for="phone">Numéro de téléphone</label>
                                <input type="text" name="phone" class="form-control">
                            </div>
                            <div class="form-group">
                                
                                <label for="msg">Message</label>
                                <textarea name="msg" class="form-control" cols="30" rows="10"></textarea>
                            
                            </div>
                            <button type="submit" class="btn btn-primary float-right">
                                Envoyer
                            </button>
                            </form>
                    </div>
                </div>
        
            </div>        
        </div>

    </div>


</section>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script> 
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>
@endsection