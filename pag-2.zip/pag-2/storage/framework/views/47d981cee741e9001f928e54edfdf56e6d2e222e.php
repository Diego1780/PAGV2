<?php $__env->startSection('content'); ?>
<section >
    <div id="article">
        <div class="container" style=" margin: 20px 70px 70px;">
            <div class=" card">
                        <!-- img class="h-50 card-img-top" src='img/moto.png' alt="Card image cap" style="max-width: 30rem;"-->
                <center>
                
                    <h4 class="card-title">Qui sommes-nous ?</h4>
                </center>

                <div class="text-align: center">
                    <p class="card-text"  ;" > <font size="5">
                        Productions d’avant-garde est une agence de marketing spécialisée
                        en influence. <br> <br>
                        Nous agissons en majorité sur trois piliers : <br> <br>
                        <mark>Influence</mark> : Nous efforcer d’apporter un vent de fraîcheur dans le
                        marketing d’influence.  Arrêter le « télé-achat digital » et construire de
                        réels partenariats avec nos clients. <br> Cette vision nous a permis d’être
                        sollicités par des acteurs majeurs de la communication pour les aider à
                        renouveler leur approche des partenariats influenceurs. <br> <br>
                        <mark>Stratégie de marque</mark> : Nous accompagnons nos partenaires sur des
                        sujets 360° allant de la refonte totale de marque, à une simple stratégie
                        réseaux sociaux et/ou digitale. <br> <br>
                        <mark>Identité visuelle</mark> : Que serait une stratégie de communication sans
                        image forte ? <br> Pour chaque brief, nous essayons de donner du sens aux
                        visuels que nous créons pour que les concepts soient à la fois dans l’ère
                        du temps et en adéquation avec l’image de la marque. 


                    </p> <br> <br>
    <center><h4 class="card-title"> Les fondateurs</h4></center> <br>
                    <div class="card-deck">
  <div class="card">
    <img class="card-img-top" src="..." alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Guillaume</h5>
        <p class="card-text-2">
        
            Ancien fiscaliste dans un cabinet d’affaires international, Guillaume est
            passé de la créativité des montages juridico-financiers à celle de la
            création de concepts de communication pour les marques. 

        </p>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="..." alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Karim</h5>
      <p class="card-text-2">
      
        Manager d’influenceurs, Karim a acquis une vision globale du secteur
        après plus de 10 ans passés à gérer, concevoir, et mettre en oeuvre des
        partenariats entre influenceurs et marques.
      </p>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="..." alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Anis</h5>
      <p class="card-text-2">
      
        Ancien planneur stratégique au sein d’un grand groupe de
        communication, il a acquis une expertise transversale lui permettant
        d’accompagner ses clients sur un large spectre de problématiques,
        notamment dans le secteur automobile.
      
      </p>
    </div>
  </div>
</div>



                </div>

                



                    <a href="#" style="color: rgb(0,0,0);"><i id='icon' class="fa fa-angle-double-up" style="font-size:36px"></i></a>

            </div>    
        </div>
    </div>





</section>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/yanis/pag/site-web/pag-2/resources/views/apropos.blade.php ENDPATH**/ ?>