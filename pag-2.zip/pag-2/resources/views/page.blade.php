@extends('layout')


@section('content')

    <center>
        <img src="/img/coming.jpg" alt="">    
    </center>

@endsection

</section>    

